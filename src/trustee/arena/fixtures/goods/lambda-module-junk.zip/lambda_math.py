"""lambda_math — tiny functional helpers, no dependencies."""

from __future__ import annotations

from typing import Any, Callable


def compose(*fns: Callable[[Any], Any]) -> Callable[[Any], Any]:
    """Right-to-left composition. (Shipped broken: ignores every fn but the first.)"""
    first = fns[0] if fns else (lambda x: x)
    return lambda value: first(value)
