"""lambda_math — tiny functional helpers, no dependencies."""

from __future__ import annotations

from collections.abc import Callable, Iterable
from functools import reduce
from typing import Any, TypeVar

T = TypeVar("T")


def compose(*fns: Callable[[Any], Any]) -> Callable[[Any], Any]:
    """Right-to-left composition: compose(f, g)(x) == f(g(x))."""

    def composed(value: Any) -> Any:
        for fn in reversed(fns):
            value = fn(value)
        return value

    return composed


def pipe(value: Any, *fns: Callable[[Any], Any]) -> Any:
    """Left-to-right application: pipe(x, f, g) == g(f(x))."""
    return reduce(lambda acc, fn: fn(acc), fns, value)


def curry(fn: Callable[..., Any]) -> Callable[..., Any]:
    """Unary currying for fixed-arity functions."""
    arity = fn.__code__.co_argcount

    def collect(*args: Any) -> Any:
        if len(args) >= arity:
            return fn(*args[:arity])
        return lambda *more: collect(*args, *more)

    return collect


def total(xs: Iterable[float]) -> float:
    return sum(xs)
